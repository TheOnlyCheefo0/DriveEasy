<?php
session_start();
include 'db_connect.php'; // Include the database connection

// Ensure the user is authenticated
if (!isset($_SESSION['user_email'])) {
    echo 'You must be logged in to view your loan history.';
    exit;
}

$borrowerEmail = $_SESSION['user_email'];

// Fetch borrower's details and loan information from the database
$sql = "SELECT * FROM loan_applications WHERE email='$borrowerEmail'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $borrower = $result->fetch_assoc();
} else {
    echo "Error: Borrower details not found.";
    exit();
}

// Fetch loan requests and payments in one query to create a combined history
$sql_history = "(
    SELECT 'Request' AS transaction_type, DATE(request_date) AS transaction_date, requested_amount AS amount, status, request_id AS id
    FROM loan_requests
    WHERE borrower_id = ?
) UNION (
    SELECT 'Payment' AS transaction_type, DATE(date_paid) AS transaction_date, amount_paid AS amount, 'Paid' AS status, payment_id AS id
    FROM loan_payments
    WHERE loan_id = ?
)
ORDER BY transaction_date";

$stmt_history = $conn->prepare($sql_history);
$stmt_history->bind_param("ii", $borrower['id'], $borrower['id']);
$stmt_history->execute();
$result_history = $stmt_history->get_result();

// Start with the original loan amount
$current_balance = $borrower['original_amount'];

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Loan History</title>
    <style>
        body {
            font-family: 'Montserrat', sans-serif;
            background-color: #f4f4f4; /* Light background color */
            margin: 0;
            padding: 20px;
        }

        #loanHistory {
            background-color: #ffffff;
            padding: 20px;
            margin: 20px auto;
            width: 80%;
            max-width: 800px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        #loanHistory h2 {
            color: #38a37f; /* Title color */
            text-align: center;
        }

        button {
            background-color: #38a37f; /* Button color */
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            margin: 10px 0;
            transition: background-color 0.3s;
        }

        button:hover {
            background-color: #2e8c66; /* Darker shade on hover */
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        table th, table td {
            border: 1px solid #ddd;
            padding: 12px;
            text-align: left;
        }

        table th {
            background-color: #f0ad4e; /* Header background color */
            color: #ffffff; /* Header text color */
        }

        table tr:nth-child(even) {
            background-color: #f9f9f9; /* Even row color */
        }

        table tr:hover {
            background-color: #f1f1f1; /* Hover color */
        }
    </style>
</head>

<body>

<section id="loanHistory">
    <h2>Your Loan Transaction History</h2>
    
    <?php
    // Check if there are transactions
    if ($result_history->num_rows > 0) {
        // Display transaction history in a table
        echo '<table>
                <thead>
                    <tr>
                        <th>Transaction Type</th>
                        <th>Transaction Date</th>
                        <th>Amount</th>
                        <th>Status</th>
                        <th>New Balance</th>
                    </tr>
                </thead>
                <tbody>';

        // Loop through the results to display transactions
        while ($row = $result_history->fetch_assoc()) {
            // Update the balance based on transaction type
            if ($row['transaction_type'] == 'Request' && $row['status'] == 'Approved') {
                $current_balance += $row['amount'];
            } elseif ($row['transaction_type'] == 'Payment') {
                $current_balance -= $row['amount'];
            }

            // Display transaction details
            echo '<tr>
                    <td>' . htmlspecialchars($row['transaction_type']) . '</td>
                    <td>' . htmlspecialchars($row['transaction_date']) . '</td>
                    <td>₱' . number_format($row['amount'], 2) . '</td>
                    <td>' . htmlspecialchars($row['status']) . '</td>
                    <td>₱' . number_format($current_balance, 2) . '</td>
                </tr>';
        }

        echo '</tbody>
            </table>';
    } else {
        echo '<p>No loan transactions found for this user.</p>';
    }

    $stmt_history->close();
    $conn->close();
    ?>
    <section style="margin-top:50px;">
        <button onclick="window.history.back()">Back</button> <!-- Back button -->
    </section>
</section>

</body>
</html>
