<?php
include 'db_connect.php';

// Get loan ID and amount paid from request
$loan_id = $_GET['loan_id'];
$amount_paid = isset($_GET['amount_paid']) ? $_GET['amount_paid'] : 0;


// Fetch the current loan amount
$select_amount_sql = "SELECT amount FROM loan_applications WHERE id = ?";
$select_stmt = $conn->prepare($select_amount_sql);
$select_stmt->bind_param("i", $loan_id);
$select_stmt->execute();
$select_stmt->bind_result($current_amount);
$select_stmt->fetch();
$select_stmt->close();

if ($amount_paid > 0) {
    // Fetch the current loan amount
    $select_amount_sql = "SELECT amount FROM loan_applications WHERE id = ?";
    $select_stmt = $conn->prepare($select_amount_sql);
    $select_stmt->bind_param("i", $loan_id);
    $select_stmt->execute();
    $select_stmt->bind_result($current_amount);
    $select_stmt->fetch();
    $select_stmt->close();

    // Check if the payment is higher than the remaining loan amount
    if ($amount_paid > $current_amount) {
        echo "Error: Payment amount exceeds the current loan balance.";
        exit();
    }
}

// Fetch all payments for the given loan
$sql = "SELECT amount_paid, date_paid FROM loan_payments WHERE loan_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $loan_id);
$stmt->execute();
$result = $stmt->get_result();

// Check if the payment exceeds the remaining amount and do not display anything if true
if ($amount_paid > $current_amount) {
    echo "Error: Payment amount exceeds the current loan balance.";
    exit();
}

$output = "<ul>";
while ($row = $result->fetch_assoc()) {
    $output .= "<li>₱" . number_format($row['amount_paid']) . " - " . date("F d, Y", strtotime($row['date_paid'])) . "</li>";
}
$output .= "</ul>";

echo $output;

// Close connections
$stmt->close();
$conn->close();
?>
