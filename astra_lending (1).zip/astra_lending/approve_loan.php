<?php
include 'db_connect.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $loanId = $_POST['loan_id'];

    // Step 1: Update the loan status to 'Approved'
    $sql = "UPDATE loan_applications SET status = 'Approved' WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $loanId);

    if ($stmt->execute()) {
        // Step 2: Fetch the borrower ID from the loan application
        $borrower_sql = "SELECT borrower_id FROM loan_applications WHERE id = ?";
        $borrower_stmt = $conn->prepare($borrower_sql);
        $borrower_stmt->bind_param("i", $loanId);
        $borrower_stmt->execute();
        $borrower_result = $borrower_stmt->get_result();

        if ($borrower_result->num_rows > 0) {
            $row = $borrower_result->fetch_assoc();
            $borrower_id = $row['borrower_id'];

            // Step 3: Insert a notification for the borrower
            $message = "Your loan request has been approved.";
            $notification_sql = "INSERT INTO notifications (borrower_id, message) VALUES (?, ?)";
            $notification_stmt = $conn->prepare($notification_sql);
            $notification_stmt->bind_param("is", $borrower_id, $message);

            if ($notification_stmt->execute()) {
                echo "Loan approved successfully and notification sent.";
            } else {
                echo "Loan approved, but failed to send notification: " . $notification_stmt->error;
            }

            $notification_stmt->close();
        } else {
            echo "Loan approved, but borrower details not found.";
        }

        $borrower_stmt->close();
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
}
?>
