<?php
session_start();
include 'db_connect.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $requestedAmount = $_POST['requestedAmount'];
    $borrowerEmail = $_SESSION['user_email'];

    // Fetch the borrower details based on their session email
    $sql = "SELECT id, name, phone, email FROM loan_applications WHERE email = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $borrowerEmail);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $borrower = $result->fetch_assoc();
        $borrowerId = $borrower['id'];

        // Insert the new loan request with the existing borrower ID
        $insertSql = "INSERT INTO loan_requests (borrower_id, requested_amount) VALUES (?, ?)";
        $insertStmt = $conn->prepare($insertSql);
        $insertStmt->bind_param("id", $borrowerId, $requestedAmount);

        if ($insertStmt->execute()) {
            echo "New loan request submitted successfully.";
        } else {
            echo "Error: " . $insertStmt->error;
        }

        $insertStmt->close();
    } else {
        echo "Error: Borrower details not found.";
    }

    $stmt->close();
    $conn->close();
}
?>
