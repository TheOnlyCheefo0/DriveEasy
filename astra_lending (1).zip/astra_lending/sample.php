<?php
session_start();

// Check if the user is logged in as a lender
if (!isset($_SESSION['user_email']) || $_SESSION['user_type'] != 'lender') {
    header("Location: lender_sign_in.php");
    exit();
}

// Include the database connection
include 'db_connect.php';

// Fetch all loan applications including the requested ones
$sql = "SELECT loan_applications.id, loan_applications.name, loan_applications.email, loan_applications.phone, loan_applications.amount, loan_applications.status, loan_applications.interest_rate, loan_applications.total_amount
        FROM loan_applications
        WHERE status = 'Approved' OR status = 'Requested' OR status = 'Pending' OR status = 'Confirmed'";

$result = $conn->query($sql);



$finalsql = "SELECT 
        loan_applications.id, 
        loan_applications.name, 
        loan_applications.email, 
        loan_applications.phone,
        loan_applications.amount,
        loan_applications.original_amount,
        IFNULL(SUM(loan_requests.requested_amount), 0) AS total_requested_amount,
        loan_applications.status, 
        loan_applications.interest_rate, 
        loan_applications.application_date
    FROM loan_applications
    LEFT JOIN loan_requests ON loan_applications.id = loan_requests.borrower_id AND loan_requests.status = 'Approved'
    WHERE loan_applications.status = 'Approved'
    GROUP BY loan_applications.id";

$finalresult = $conn->query($finalsql);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$pendingapplication = "SELECT loan_applications.id, loan_applications.name, loan_applications.email, loan_applications.phone, loan_applications.amount, loan_applications.status, loan_applications.interest_rate, loan_applications.total_amount
                     FROM loan_applications
                     WHERE status = 'Confirmed'";

$pendingapplication_result = $conn->query($pendingapplication);

$loan_application_sql = "SELECT loan_applications.id, loan_applications.name, loan_applications.email, loan_applications.phone, loan_applications.amount, loan_applications.status, loan_applications.interest_rate, loan_applications.total_amount, loan_requests.requested_amount, loan_requests.status AS request_status, loan_requests.request_id
    FROM loan_applications
    LEFT JOIN loan_requests ON loan_applications.id = loan_requests.borrower_id
    WHERE loan_applications.status = 'Confirmed' 
       OR loan_requests.status = 'Requested'";


$loan_application_result = $conn->query($loan_application_sql);



// Fetch the count of borrowers
$sql_borrower_count = "SELECT COUNT(*) as borrower_count FROM loan_applications WHERE status = 'Approved'";
$result_borrower_count = $conn->query($sql_borrower_count);
$borrower_count = 0;
if ($result_borrower_count->num_rows > 0) {
    $row_borrower_count = $result_borrower_count->fetch_assoc();
    $borrower_count = $row_borrower_count['borrower_count'];
}



// Count the pending applications from loan_applications with status 'Confirmed'
$sql_pending_count_applications = "SELECT COUNT(*) as pending_count 
                                   FROM loan_applications 
                                   WHERE status = 'Confirmed'";
$result_pending_count_applications = $conn->query($sql_pending_count_applications);
$pending_applications_count = 0;
if ($result_pending_count_applications->num_rows > 0) {
    $row_pending_count_applications = $result_pending_count_applications->fetch_assoc();
    $pending_applications_count += $row_pending_count_applications['pending_count'];
}

// Count the requested applications from loan_requests with status 'Requested'
$sql_pending_count_requests = "SELECT COUNT(*) as requested_count 
                               FROM loan_requests 
                               WHERE status = 'Requested'";
$result_pending_count_requests = $conn->query($sql_pending_count_requests);
if ($result_pending_count_requests->num_rows > 0) {
    $row_pending_count_requests = $result_pending_count_requests->fetch_assoc();
    $pending_applications_count += $row_pending_count_requests['requested_count'];
}


if ($conn->connect_error) {
    die("Connection failed: " . conn->connect_error);
}

// Fetch the sum of all loan amounts

$sql_total_amount = "SELECT SUM(amount) as total_amount FROM loan_applications WHERE status = 'Approved'";
$result_total_amount = $conn->query($sql_total_amount);
$total_amount_lent = 0;
if ($result_total_amount->num_rows > 0) {
    $row_total_amount = $result_total_amount->fetch_assoc();
    $total_amount_lent = $row_total_amount['total_amount'];
}


// Fetch the count of approved applications for the current month
$sql_approved_this_month = "SELECT COUNT(*) as approved_count FROM loan_applications WHERE status = 'Approved' AND MONTH(application_date) = MONTH(CURDATE()) AND YEAR(application_date) = YEAR(CURDATE())";
$result_approved_this_month = $conn->query($sql_approved_this_month);
$approved_this_month = 0;
if ($result_approved_this_month->num_rows > 0) {
    $row_approved_this_month = $result_approved_this_month->fetch_assoc();
    $approved_this_month = $row_approved_this_month['approved_count'];
}

// Step 1: Calculate the total amount lent last month
$sql_total_amount_last_month = "SELECT SUM(amount) as total_amount_last_month 
                                FROM loan_applications 
                                WHERE status = 'Approved' 
                                AND MONTH(application_date) = MONTH(DATE_SUB(CURDATE(), INTERVAL 1 MONTH)) 
                                AND YEAR(application_date) = YEAR(DATE_SUB(CURDATE(), INTERVAL 1 MONTH))";
$result_total_amount_last_month = $conn->query($sql_total_amount_last_month);
$total_amount_last_month = 0;

if ($result_total_amount_last_month && $result_total_amount_last_month->num_rows > 0) {
    $row_total_amount_last_month = $result_total_amount_last_month->fetch_assoc();
    $total_amount_last_month = $row_total_amount_last_month['total_amount_last_month'] ?? 0; // Ensure default value of 0
}

// Step 2: Calculate the total amount lent this month
$sql_total_amount_this_month = "SELECT SUM(amount) as total_amount_this_month 
                                FROM loan_applications 
                                WHERE status = 'Approved' 
                                AND MONTH(application_date) = MONTH(CURDATE()) 
                                AND YEAR(application_date) = YEAR(CURDATE())";
$result_total_amount_this_month = $conn->query($sql_total_amount_this_month);
$total_amount_this_month = 0;

if ($result_total_amount_this_month && $result_total_amount_this_month->num_rows > 0) {
    $row_total_amount_this_month = $result_total_amount_this_month->fetch_assoc();
    $total_amount_this_month = $row_total_amount_this_month['total_amount_this_month'] ?? 0; // Ensure default value of 0
}

// Step 3: Calculate the percentage change
$percentage_change = 0;
if ($total_amount_last_month > 0) {
    $percentage_change = ((($total_amount_this_month + $total_amount_last_month) / $total_amount_last_month) * 100) -100;
} else {
    // Handle the case where last month's total is 0 to avoid division by zero
    if ($total_amount_this_month > 0) {
        $percentage_change = 100; // pag wala pang data, magigign 100% increase
    }
}

// Calculate monthly interest earned
$sql_monthly_interest = "SELECT SUM(amount * (interest_rate / 100)) as monthly_interest FROM loan_applications WHERE status = 'Approved'";
$result_monthly_interest = $conn->query($sql_monthly_interest);
$monthly_interest_earned = 0;
if ($result_monthly_interest->num_rows > 0) {
    $row_monthly_interest = $result_monthly_interest->fetch_assoc();
    $monthly_interest_earned = $row_monthly_interest['monthly_interest'];
}

// Step 1: Calculate monthly interest earned this month
$sql_monthly_interest_this_month = "SELECT SUM(amount * (interest_rate / 100)) as monthly_interest_this_month 
                                    FROM loan_applications 
                                    WHERE status = 'Approved' 
                                    AND MONTH(application_date) = MONTH(CURDATE()) 
                                    AND YEAR(application_date) = YEAR(CURDATE())";
$result_monthly_interest_this_month = $conn->query($sql_monthly_interest_this_month);
$monthly_interest_earned_this_month = 0;

if ($result_monthly_interest_this_month && $result_monthly_interest_this_month->num_rows > 0) {
    $row_monthly_interest_this_month = $result_monthly_interest_this_month->fetch_assoc();
    $monthly_interest_earned_this_month = $row_monthly_interest_this_month['monthly_interest_this_month'] ?? 0;
}

// Step 2: Calculate monthly interest earned last month
$sql_monthly_interest_last_month = "SELECT SUM(amount * (interest_rate / 100)) as monthly_interest_last_month 
                                    FROM loan_applications 
                                    WHERE status = 'Approved' 
                                    AND MONTH(application_date) = MONTH(DATE_SUB(CURDATE(), INTERVAL 1 MONTH)) 
                                    AND YEAR(application_date) = YEAR(DATE_SUB(CURDATE(), INTERVAL 1 MONTH))";
$result_monthly_interest_last_month = $conn->query($sql_monthly_interest_last_month);
$monthly_interest_earned_last_month = 0;

if ($result_monthly_interest_last_month && $result_monthly_interest_last_month->num_rows > 0) {
    $row_monthly_interest_last_month = $result_monthly_interest_last_month->fetch_assoc();
    $monthly_interest_earned_last_month = $row_monthly_interest_last_month['monthly_interest_last_month'] ?? 0;
}

// Step 3: Calculate the percentage increase for monthly interest earned
$interest_percentage_increase = 0;
if ($monthly_interest_earned_last_month > 0) {
    $interest_percentage_increase = ((($monthly_interest_earned_this_month + $monthly_interest_earned_last_month) / $monthly_interest_earned_last_month) * 100) - 100;
} else if ($monthly_interest_earned_this_month > 0) {
    $interest_percentage_increase = 100; // Treat as 100% increase when there's no previous data

    
}
//echo "Total Amount Lent This Month: $total_amount_this_month<br>";
//echo "Total Amount Lent Last Month: $total_amount_last_month<br>";
//echo "Monthly Interest Earned This Month: $monthly_interest_earned_this_month<br>";
//echo "Monthly Interest Earned Last Month: $monthly_interest_earned_last_month<br>";

// Fetch loan applications
$sql_applications = "SELECT id, name, email, phone, amount, interest_rate, total_amount, application_date 
                     FROM loan_applications 
                     WHERE status = 'Approved' OR status = 'Confirmed'";
$result_applications = $conn->query($sql_applications);


// Fetch loan requests
$sql_requests = "SELECT loan_requests.request_id, loan_requests.borrower_id, loan_requests.requested_amount, loan_requests.request_date, loan_applications.name 
                 FROM loan_requests 
                 JOIN loan_applications ON loan_requests.borrower_id = loan_applications.id 
                 WHERE loan_requests.status = 'Requested' OR loan_requests.status = 'Approved'";
$result_requests = $conn->query($sql_requests);


// Fetch loan payments
$sql_payments = "SELECT loan_payments.payment_id, loan_payments.loan_id, loan_payments.amount_paid, loan_payments.date_paid, loan_applications.name 
                 FROM loan_payments 
                 JOIN loan_applications ON loan_payments.loan_id = loan_applications.id";
$result_payments = $conn->query($sql_payments);

$activities = [];

// Loan Applications
while ($row = $result_applications->fetch_assoc()) {
    $activities[] = [
        'activity_type' => 'Application',
        'name' => $row['name'],
        'amount' => $row['amount'],
        'date' => $row['application_date']
    ];
}

// Loan Requests
while ($row = $result_requests->fetch_assoc()) {
    $activities[] = [
        'activity_type' => 'Request',
        'name' => $row['name'],
        'amount' => $row['requested_amount'],
        'date' => $row['request_date']
    ];
}

// Loan Payments
while ($row = $result_payments->fetch_assoc()) {
    $activities[] = [
        'activity_type' => 'Payment',
        'name' => $row['name'],
        'amount' => $row['amount_paid'],
        'date' => $row['date_paid']
    ];
}

// Sort activities by date (latest first)
usort($activities, function ($a, $b) {
    return strtotime($b['date']) - strtotime($a['date']);
});


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Astra Dashboard</title>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/sample_style.css">

    <script>
        function showSection(sectionId) {
            document.getElementById('dashboard').classList.add('hidden');
            document.getElementById('borrowers').classList.add('hidden');
            document.getElementById('loan-application').classList.add('hidden');
            document.getElementById(sectionId).classList.remove('hidden');
        }

        function searchBorrowers() {
            let input = document.getElementById('searchInput').value.toLowerCase();
            let rows = document.querySelectorAll('#borrowers table tbody tr');

            rows.forEach(row => {
                let name = row.cells[1].innerText.toLowerCase();
                if (name.includes(input)) {
                    row.style.display = '';
                } else {
                    row.style.display = 'none';
                }
            });
        }
    </script>
    <script>
        function openMoreDetails(id, name, email, phone, amount, interestRate, totalAmount, applicationDate) {
            document.getElementById('modalId').innerText = id;
            document.getElementById('modalName').innerText = name;
            document.getElementById('modalEmail').innerText = email;
            document.getElementById('modalPhone').innerText = phone;
            document.getElementById('modalAmount').innerText = amount;
            document.getElementById('modalInterestRate').innerText = interestRate;
            document.getElementById('modalTotalAmount').innerText = totalAmount;
            document.getElementById('modalApplicationDate').innerText = applicationDate;
            document.getElementById('detailsModal').style.display = 'block';
        }

        function closeMoreDetails() {
            document.getElementById('detailsModal').style.display = 'none';
        }
    </script>
    <script>
        function openMoreDetails(id, name, email, phone, amount, interestRate, totalAmount, applicationDate) {
    document.getElementById('modalId').innerText = id;
    document.getElementById('modalName').innerText = name;
    document.getElementById('modalEmail').innerText = email;
    document.getElementById('modalPhone').innerText = phone;
    document.getElementById('modalAmount').innerText = amount;
    document.getElementById('modalInterestRate').innerText = interestRate;
    document.getElementById('modalTotalAmount').innerText = totalAmount;
    document.getElementById('modalApplicationDate').innerText = applicationDate;
    
    // Fetch and display payment records
    fetchPaymentRecords(id);
    
    document.getElementById('detailsModal').style.display = 'block';
}
function grantLoan(loanId) {
        var xhr = new XMLHttpRequest();
        xhr.open('POST', 'grant_loan.php', true);
        xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
        xhr.onload = function() {
            if (xhr.status === 200) {
                alert('Loan granted successfully!');
                location.reload(); // Reload the page to update the loan status and amount
            } else {
                alert('Failed to grant the loan.');
            }
        };
        xhr.send('loan_id=' + loanId);
    }
function fetchPaymentRecords(loanId) {
    // AJAX call to fetch payment records
    var xhr = new XMLHttpRequest();
    xhr.open('GET', 'fetch_payments.php?loan_id=' + loanId, true);
    xhr.onload = function() {
        if (xhr.status === 200) {
            document.getElementById('paymentRecords').innerHTML = xhr.responseText;
        }
    };
    xhr.send();
}

function closeMoreDetails() {
    document.getElementById('detailsModal').style.display = 'none';
}

function openPaymentModal() {
    document.getElementById('paymentModal').style.display = 'block';
}

function closePaymentModal() {
    document.getElementById('paymentModal').style.display = 'none';
}

function recordPayment() {
    var loanId = document.getElementById('modalId').innerText;
    var amountPaid = parseFloat(document.getElementById('amountPaid').value);
    var currentLoanAmount = parseFloat(document.getElementById('modalAmount').innerText.replace(/[^0-9.-]+/g, ""));

    // Check if the payment exceeds the current loan amount
    if (amountPaid > currentLoanAmount) {
        alert('Payment exceeds the current loan amount. Please enter a valid amount.');
        return;
    }

    // AJAX call to record a payment
    var xhr = new XMLHttpRequest();
    xhr.open('POST', 'record_payment.php', true);
    xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
    xhr.onload = function() {
        if (xhr.status === 200) {
            alert('Payment recorded successfully!');
            closePaymentModal();
            fetchPaymentRecords(loanId);

            // Update the current loan amount
            var newLoanAmount = currentLoanAmount - amountPaid;
            document.getElementById('modalAmount').innerText = '₱' + newLoanAmount.toLocaleString();

            // Update interest rate and total amount if needed
            var newInterestRate = newLoanAmount < 10000 ? 15 : 12;
            var newTotalAmount = newLoanAmount * (newInterestRate / 100);

            document.getElementById('modalInterestRate').innerText = newInterestRate;
            document.getElementById('modalTotalAmount').innerText = '₱' + newTotalAmount.toLocaleString();

            // Update the total amount lent on the dashboard dynamically
            var currentTotalAmount = parseFloat(document.getElementById('totalAmountLent').innerText.replace(/[^0-9.-]+/g, ""));
            var newTotalAmountLent = currentTotalAmount - amountPaid;
            document.getElementById('totalAmountLent').innerText = '₱' + newTotalAmountLent.toLocaleString();
        }
    };
    xhr.send('loan_id=' + loanId + '&amount_paid=' + amountPaid);
}
        function approveLoan(loanId) {
            var xhr = new XMLHttpRequest();
            xhr.open('POST', 'approve_loan.php', true);
            xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
            xhr.onload = function() {
                if (xhr.status === 200) {
                    alert('Loan approved successfully!');
                    location.reload(); // Reload the page to update the loan status
                } else {
                    alert('Failed to approve loan.');
                }
            };
            xhr.send('loan_id=' + loanId);
        }
    </script>
</head>
<body>
    <div class="sidebar">
    <div class="sidebar-header">
    <img src="images/astra_logo.svg" alt="Astra Lending Logo" class="logo">
        <h2>Astra Lending Co.</h2>
    </div>
    <ul>
        <li><a href="javascript:void(0)" onclick="showSection('dashboard')">Dashboard</a></li>
        <li><a href="javascript:void(0)" onclick="showSection('borrowers')">Borrowers</a></li>
        <li><a href="javascript:void(0)" onclick="showSection('loan-application')">Loan Application</a><span id="notification-count"><?php echo $pending_applications_count; ?></span></li>
        <style>
            /* Style for the notification count badge */
#notification-count {
    background-color: #f6941d; /* Orange background */
    color: #ffffff; /* White text */
    padding: 4px 20px ; /* Padding for the badge */
    border-radius: 200%; /* Rounded to create a badge effect */
    font-size: .8em; /* Smaller font size */
    position: absolute; /* Absolute positioning */
    top: 15px; /* Adjust this value for vertical alignment */
    left: auto; /* Adjust to align horizontally with "Loan Application" */
    transform: translateX(-50%); /* Center horizontally */
}

        </style>
    </ul>
    <div class="logout">
        <a href="logout.php">Logout</a>
    </div>
    </div>
    <div class="content">
        <div class="section" id="dashboard">
            <div class="header">
                <h1>Dashboard</h1>
            </div>
            <div class="cards">
                <div class="card card-1">
                    <h3>Number of Borrowers</h3>
                    <p><?php echo $borrower_count; ?></p>
                    <p>+<?php echo $approved_this_month; ?> People approved this month</p>
                </div>
                <div class="card card-2">
                    <h3>Total Amount Lent</h3>
                    <p>₱<?php echo number_format($total_amount_lent); ?></p>
                    <p><?php echo number_format($percentage_change); ?>% this month</p>
                </div>
                <div class="card card-3">
                    <h3>Monthly Interest Earned</h3>
                    <p>₱<?php echo number_format($monthly_interest_earned); ?></p>
                    <p><?php echo number_format($interest_percentage_increase); ?>% this month</p>
                </div>
            </div>
            <!-- Updated Recent Applications Section -->
            <h1>Recent Activities</h1>
            <div class="scrollable-table">
            <table>
    <thead>
        <tr>
            <th>Borrower Name</th>
            <th>Activity Type</th>
            <th>Amount</th>
            <th>Date</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($activities as $activity) { ?>
            <tr>
                <td><?php echo $activity['name']; ?></td>
                <td><?php echo $activity['activity_type']; ?></td>
                <td>₱<?php echo number_format($activity['amount']); ?></td>
                <td><?php echo date("F d, Y", strtotime($activity['date'])); ?></td>
            </tr>
        <?php } ?>
    </tbody>
</table>

            </div>
        </div>
        <div class="content">
        <div class="section hidden" id="borrowers">
            <div class="header">
                <h1>Approved Borrowers</h1>
            </div>
            <div class="search-bar">
                <input type="text" id="searchInput" onkeyup="searchBorrowers()" placeholder="Search by name...">
            </div>
            <div class="scrollable-table">
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Phone Number</th>
                            <th>Loan Amount</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($row = $finalresult->fetch_assoc()) { 
                            // Calculate the total loan amount by adding original amount and approved requests
                            $total_loan_amount = $row['original_amount'] + $row['total_requested_amount'];
                        ?>
                            <tr>
                                <td data-label="ID"><?php echo $row['id']; ?></td>
                                <td data-label="Name"><?php echo $row['name']; ?></td>
                                <td data-label="Phone Number"><?php echo $row['phone']; ?></td>
                                <td data-label="Loan Amount">₱<?php echo number_format($total_loan_amount); ?></td>
                                <td data-label="Actions">
                                    
                                    <button class="more-button" onclick="openMoreDetails('<?php echo $row['id']; ?>', '<?php echo $row['name']; ?>', '<?php echo $row['email']; ?>', '<?php echo $row['phone']; ?>', '<?php echo $total_loan_amount; ?>', '<?php echo $row['interest_rate']; ?>',
                                    '<?php echo $row['amount']; ?>', '<?php echo $row['application_date']; ?>')">More</button>
                                </td>
                            </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
            <div id="detailsModal" class="modal" style="display: none;">
    <div class="modal-content">
        <span class="close" onclick="closeMoreDetails()">&times;</span>
        <h2>Borrower Details</h2>
        <p><strong>ID:</strong> <span id="modalId"></span></p>
        <p><strong>Name:</strong> <span id="modalName"></span></p>
        <p><strong>Email:</strong> <span id="modalEmail"></span></p>
        <p><strong>Phone Number:</strong> <span id="modalPhone"></span></p>
        <p><strong>Loan Amount:</strong> <span id="modalAmount"></span></p>
        <p><strong>Interest Rate:</strong> <span id="modalInterestRate"></span>%</p>
        <p><strong>Total Amount:</strong> <span id="modalTotalAmount"></span></p>
        <p><strong>Application Date:</strong> <span id="modalApplicationDate"></span></p>
        
        <h3>Payment Records</h3>
        <div id="paymentRecords">
            <!-- Payments will be displayed here -->
        </div>

        <button>Edit Details</button>
        <button onclick="openPaymentModal()">Record Payment</button>
    </div>
</div>

<!-- Payment Modal -->
<div id="paymentModal" class="modal" style="display: none;">
    <div class="modal-content">
        <span class="close" onclick="closePaymentModal()">&times;</span>
        <h2>Record a Payment</h2>
        <form id="paymentForm">
            <input type="hidden" id="loanId">
            <label for="amountPaid">Amount Paid:</label>
            <input type="number" id="amountPaid" step="0.01" required>
            <button type="button" onclick="recordPayment()">Submit Payment</button>
        </form>
    </div>
</div>

                </div>
<style>
form button {
    background-color: #38a37f; /* Green background */
    color: white; /* White text */
    border: none; /* Remove border */
    padding: 10px 15px; /* Add some padding */
    font-size: 1rem; /* Adjust font size */
    border-radius: 5px; /* Rounded corners */
    cursor: pointer; /* Pointer cursor on hover */
    transition: background-color 0.3s, transform 0.2s; /* Add transition for hover effect */
}

form button:hover {
    background-color: #45a049; /* Darker green on hover */
    transform: translateY(-2px); /* Slight lift on hover */
}

form button:active {
    background-color: #3e8e41; /* Even darker green when clicked */
    transform: translateY(1px); /* Press down effect */
}
                        </style>
<div class="section hidden" id="loan-application">
    <div class="header">
        <h1>Loan Applications</h1>
    </div>
    <table>
    <thead>
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Phone Number</th>
            <th>Loan Amount</th>
            <th>Status</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
   <?php while ($row = $loan_application_result->fetch_assoc()) {
       if ($loan_application_result === false) {
           echo "Error: " . $conn->error;
       }
    ?>
    <tr>
        <td data-label="ID"><?php echo $row['id']; ?></td>
        <td data-label="Name"><?php echo $row['name']; ?></td>
        <td data-label="Phone Number"><?php echo $row['phone']; ?></td>
        <td data-label="Loan Amount">
            <?php 
                if ($row['request_status'] == 'Requested') {
                    echo '₱' . number_format($row['requested_amount']);
                } else {
                    echo '₱' . number_format($row['amount']);
                }
            ?>
        </td>
        <td data-label="Status"><?php echo $row['status'] == 'Confirmed' ? 'Confirmed' : $row['request_status']; ?></td>

        
        <td data-label="Actions">
    <?php if ($row['request_status'] == 'Requested') { ?>
        <form action="grant_loan.php" method="POST" style="display: inline-block;">
            <input type="hidden" name="loan_id" value="<?php echo $row['id']; ?>"> <!-- Dynamically set loan ID -->
            <input type="hidden" name="request_id" value="<?php echo isset($row['request_id']) ? $row['request_id'] : ''; ?>"> <!-- Dynamically set request ID -->
            <button type="submit" class="grant-button">Grant</button>
        </form>

        <form action="reject_loan.php" method="POST" style="display: inline-block;">
            <input type="hidden" name="loan_id" value="<?php echo $row['id']; ?>"> <!-- Dynamically set loan ID -->
            <input type="hidden" name="request_id" value="<?php echo isset($row['request_id']) ? $row['request_id'] : ''; ?>"> <!-- Dynamically set request ID -->
            <button type="submit" class="reject-button">Reject</button>
        </form>
    <?php } elseif ($row['status'] == 'Confirmed') { ?>
        <button class="approve-button" onclick="approveLoan('<?php echo $row['id']; ?>')">Approve</button>
    <?php } ?>
</td>


<script>
    function confirmGrant(loanId, borrowerName, requestedAmount) {
        return confirm(`Are you sure you want to grant a loan of ₱${requestedAmount.toLocaleString()} to ${borrowerName}?`);
    }
</script>



    </tr>
    <?php } ?>
</tbody>

</table>

<style>
    .grant-button {
        background-color: #3aa380; /* Orange background */
        color: #ffffff; /* White text */
        border: none; /* Remove border */
        padding: 10px 15px; /* Add padding */
        font-size: 1rem; /* Font size */
        border-radius: 5px; /* Rounded corners */
        cursor: pointer; /* Pointer cursor on hover */
        transition: background-color 0.3s, transform 0.2s; /* Add hover transition */
    }

    .grant-button:hover {
        background-color: #e68310; /* Darker orange on hover */
        transform: translateY(-2px); /* Slight lift on hover */
    }

    .grant-button:active {
        background-color: #cc750f; /* Even darker orange when clicked */
        transform: translateY(1px); /* Press down effect */
    }

    .approve-button {
        background-color: #4CAF50; /* Green background */
        color: #ffffff; /* White text */
        border: none; /* Remove border */
        padding: 10px 15px; /* Add padding */
        font-size: 1rem; /* Font size */
        border-radius: 5px; /* Rounded corners */
        cursor: pointer; /* Pointer cursor on hover */
        transition: background-color 0.3s, transform 0.2s; /* Add hover transition */
    }
    .approve-button:hover {
        background-color: #45a049; /* Darker green on hover */
        transform: translateY(-2px); /* Slight lift on hover */
    }

    .approve-button:active {
        background-color: #3e8e41; /* Even darker green when clicked */
        transform: translateY(1px); /* Press down effect */
    }
    .reject-button {
        background-color: #e74c3c; /* Red background */
        color: #ffffff; /* White text */
        border: none; /* Remove border */
        padding: 10px 15px; /* Add padding */
        font-size: 1rem; /* Font size */
        border-radius: 5px; /* Rounded corners */
        cursor: pointer; /* Pointer cursor on hover */
        transition: background-color 0.3s, transform 0.2s; /* Add hover transition */
    }

    .reject-button:hover {
        background-color: #c0392b; /* Darker red on hover */
        transform: translateY(-2px); /* Slight lift on hover */
    }

    .reject-button:active {
        background-color: #a93226; /* Even darker red when clicked */
        transform: translateY(1px); /* Press down effect */
    }

</style>
</div>
</body>
</html>

<?php
$conn->close();
?>