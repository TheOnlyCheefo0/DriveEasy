<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "astra_lending_db";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

