<?php
session_start();

// Check if the user is logged in as a borrower
if (!isset($_SESSION['user_email']) || $_SESSION['user_type'] != 'borrower') {
    header("Location: borrower_sign_in.php");
    exit();
}

// Include the database connection
include 'db_connect.php';

// Get the borrower's email from session
$borrower_email = $_SESSION['user_email'];

// Fetch borrower's details and loan information from the database
$sql = "SELECT * FROM loan_applications WHERE email='$borrower_email'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $borrower = $result->fetch_assoc();
} else {
    echo "Error: Borrower details not found.";
    exit();
}

// Step 1: Calculate Total Loan Amount
$loan_id = $borrower['id'];
$original_amount = $borrower['original_amount'];

// Fetch the total approved loan requests for the borrower
$sql_approved_requests = "SELECT SUM(requested_amount) AS total_approved_requests FROM loan_requests WHERE borrower_id = $loan_id AND status = 'Approved'";
$result_approved_requests = $conn->query($sql_approved_requests);
$total_approved_requests = 0;

if ($result_approved_requests->num_rows > 0) {
    $row_approved_requests = $result_approved_requests->fetch_assoc();
    $total_approved_requests = $row_approved_requests['total_approved_requests'];
}

// Calculate total loan amount
$total_loan_amount = $original_amount + $total_approved_requests;

// Step 2: Calculate Total Payments Made
$total_paid = 0;
$payments = [];

$sql_payments = "SELECT amount_paid, date_paid FROM loan_payments WHERE loan_id = $loan_id";
$result_payments = $conn->query($sql_payments);

if ($result_payments->num_rows > 0) {
    while ($row_payment = $result_payments->fetch_assoc()) {
        $total_paid += $row_payment['amount_paid'];
        $payments[] = $row_payment;
    }
}

// Step 3: Calculate Current Balance
$current_balance = $total_loan_amount - $total_paid;

// Step 4: Update Interest Rate and Total Repayment Amount
$interest_rate = $current_balance >= 10000 ? 12 : 15;
$total_amount = $current_balance + ($current_balance * ($interest_rate / 100));

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Borrower Dashboard - Astra Lending</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/borrower_dashboard.css">
    <script>
        function toggleUpdateForm() {
            var form = document.getElementById('updateForm');
            if (form.style.display === 'none' || form.style.display === '') {
                form.style.display = 'block';
            } else {
                form.style.display = 'none';
            }
        }

        function validatePasswordMatch() {
            var password = document.getElementById('password').value;
            var confirmPassword = document.getElementById('confirmPassword').value;
            if (password !== confirmPassword) {
                alert('Passwords do not match. Please try again.');
                return false;
            }
            return true;
        }
        function openNewLoanRequestModal() {
            document.getElementById('newLoanRequestModal').style.display = 'block';
        }

        function closeNewLoanRequestModal() {
            document.getElementById('newLoanRequestModal').style.display = 'none';
        }

        function submitNewLoanRequest() {
            var requestedAmount = parseFloat(document.getElementById('requestedAmount').value);

            // AJAX call to submit the new loan request
            var xhr = new XMLHttpRequest();
            xhr.open('POST', 'submit_new_loan_request.php', true);
            xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
            xhr.onload = function() {
                if (xhr.status === 200) {
                    alert('New loan request submitted successfully!');
                    closeNewLoanRequestModal();
                } else {
                    alert('Failed to submit loan request.');
                }
            };
            xhr.send('requestedAmount=' + requestedAmount);
        }

    </script>

<header>
    <div class="logo-container">
        <a href="#" class="hometitle">
            <img src="images/astra_logo.svg" alt="Astra Lending Logo" class="logo">
            <h1>Astra Lending Co.</h1>
        </a>
    </div>
    <div class="profile-circle" onclick="document.getElementById('profileModal').style.display='block'">
    <img src="images/menu_clickable.svg" alt="Drop down">
    </div>
    <div id="profileModal" class="modal">
    <div class="modal-content">
        <span class="close" onclick="document.getElementById('profileModal').style.display='none'">&times;</span>
        <h2 style="color: #e0963b;">Profile Menu</h2>
        <ul>
            <li><a href="loan_history.php">View Loan History</a></li>
            <li><a href="#" onclick="toggleUpdateForm()">Update Password</a></li>
            <li><a href="notifications.php">Notifications</a></li>
            <li><a href="logout.php">Logout</a></li>
        </ul>
        <section id="updateForm" style="display: none;">
    <h2>Update Your Password</h2>
    <form action="update_borrower_details.php" method="POST" onsubmit="return validatePasswordMatch()">
        <label for="password">New Password:</label>
        <input type="password" id="password" name="password" placeholder="Enter new password" required><br><br>

        <label for="confirmPassword">Confirm New Password:</label>
        <input type="password" id="confirmPassword" name="confirmPassword" placeholder="Confirm new password" required><br><br>

        <input type="submit" value="Update Password">
    </form>
</section>
    </div> 
</div>

</header>


<style>    
    /* General Styling */
    body {
        font-family: 'Montserrat', sans-serif; /* Branding font */
        margin: 0;
        padding: 0;
        background-color: #f5f5f5;
        color: #333; /* General text color for better contrast */
    }

    /* Header Styling */
    header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 1rem;
        background-color: #ffffff; /* Branding green color */
        color: #ffffff;
    }

    .logo-container {
        display: flex;
        align-items: center;
    }

    .logo {
        width: 60px;
        height: auto;
        margin-right: 20px;
        margin-left: 20px;
    }

    .hometitle h1 {
        font-size: 40px;
        margin: 0;
        color: #38a37f;
        align-items: center;
        top: auto;
    }

    .profile-circle img {
        width: 40px;
        height: 40px;
        cursor: pointer;
        margin-right: 50px;
    }

    /* Modal Styling */
    .modal {
        display: none; /* Hidden by default */
        position: fixed;
        z-index: 1000;
        left: 0;
        top: 0;
        width: 100%;
        height: 100%;
        overflow: auto;
        background-color: rgba(0, 0, 0, 0.5); /* Black background with opacity */
        transition: opacity 0.4s ease-in-out;
    }

    .modal-content {
        background-color: #ffffff;
        margin: 10% auto;
        padding: 20px;
        border-radius: 12px;
        width: 90%;
        max-width: 500px;
        box-shadow: 0 6px 12px rgba(0, 0, 0, 0.3);
        position: relative;
        animation: slideDown 0.5s ease-out;
        text-align: center;
    }

    /* Close Button Styling */
    .close {
        color: #aaa;
        float: right;
        font-size: 28px;
        font-weight: bold;
        position: absolute;
        top: 15px;
        right: 20px;
        cursor: pointer;
    }

    .close:hover, .close:focus {
        color: #e0963b; /* Branding secondary orange */
        text-decoration: none;
    }

    /* Modal Heading Styling */
    .modal-content h2 {
        color: #38a37f; /* Branding color */
        font-family: 'Montserrat', sans-serif;
        font-size: 24px;
        text-shadow: 1px 1px 2px rgba(0, 0, 0, 0.2);
        margin-bottom: 20px;
    }

    /* Modal List Styling */
    .modal-content ul {
        list-style-type: none;
        padding: 0;
        margin: 0;
    }

    .modal-content ul li {
        margin: 20px 0;
    }

    .modal-content ul li a {
        text-decoration: none;
        color: #38a37f;
        font-size: 18px;
        padding: 10px;
        border-radius: 5px;
        transition: background-color 0.3s, color 0.3s, transform 0.2s;
        display: inline-block;
    }

    .modal-content ul li a:hover {
        background-color: #f6941d; /* Branding secondary color (orange) */
        color: #ffffff;
        transform: scale(1.05);
    }

    /* Form Styling */
    #updateForm {
        display: none;
        margin-top: 20px;
    }

    #updateForm h2 {
        font-size: 20px;
        color: #38a37f; /* Branding color */
    }

    #updateForm form label {
        display: block;
        margin-bottom: 5px;
        color: #333;
    }

    #updateForm form input[type="password"] {
        width: 100%;
        padding: 10px;
        margin-bottom: 15px;
        border: 1px solid #ccc;
        border-radius: 5px;
    }

    #updateForm form input[type="submit"] {
        width: 100%;
        padding: 10px;
        background-color: #38a37f; /* Branding color */
        color: #fff;
        border: none;
        border-radius: 5px;
        cursor: pointer;
        transition: background-color 0.3s, box-shadow 0.2s;
    }

    #updateForm form input[type="submit"]:hover {
        background-color: #2e8566;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
    }

    /* Button Styling */
    button {
        padding: 12px 25px;
        margin-top: 20px;
        background-color: #38a37f; /* Branding green color */
        color: #fff;
        border: none;
        border-radius: 8px;
        cursor: pointer;
        font-size: 16px;
        transition: background-color 0.3s, transform 0.2s;
    }

    button:hover {
        background-color: #2e8566;
        transform: translateY(-3px);
    }

    button:active {
        background-color: #267b5f;
        transform: translateY(1px);
    }

    /* Section Styling */
    section {
        padding: 25px;
        background-color: #ffffff;
        margin: 25px auto;
        max-width: 600px;
        border-radius: 12px;
        box-shadow: 0 6px 12px rgba(0, 0, 0, 0.2);
    }

    section h2 {
        font-size: 24px;
        color: #38a37f; /* Branding color */
        border-bottom: 3px solid #f6941d; /* Secondary color */
        padding-bottom: 10px;
        margin-bottom: 20px;
    }

    section p {
        font-size: 16px;
        color: #555;
        line-height: 1.6;
    }

    /* Payment Records List */
    ul {
        list-style: none;
        padding: 0;
    }

    ul li {
        padding: 10px;
        border-bottom: 1px solid #f0f0f0;
        font-size: 16px;
        color: #333;
    }

    /* Input Fields in the New Loan Request Modal */
    #newLoanRequestForm input[type="number"] {
        width: 100%;
        padding: 10px;
        margin-bottom: 15px;
        border: 1px solid #ccc;
        border-radius: 5px;
    }

    #newLoanRequestForm button {
        width: 100%;
        background-color: #f6941d; /* Secondary branding color (orange) */
        color: #fff;
        border-radius: 5px;
    }

    #newLoanRequestForm button:hover {
        background-color: #e08318;
    }

    /* Animation for Modal */
    @keyframes slideDown {
        from { transform: translateY(-20%); opacity: 0; }
        to { transform: translateY(0); opacity: 1; }
    }

    /* Responsive Media Queries */
    @media (max-width: 600px) {
        header {
            flex-direction: column;
            align-items: flex-start;
        }
        .modal-content {
            width: 90%;
        }
    }



</style>

<script>
    // Open the modal when the profile picture is clicked
    document.querySelector('.profile-circle').addEventListener('click', function(event) {
        event.preventDefault(); // Prevent any default behavior like page reload
        document.getElementById('profileModal').style.display = 'block';
    });

    // Close the modal when the user clicks anywhere outside the modal content
    window.onclick = function(event) {
        var modal = document.getElementById('profileModal');
        if (event.target == modal) {
            modal.style.display = 'none';
        }
    };
</script>

<section>
    <h2>Your Personal Details</h2>
    <p><strong>Full Name:</strong> <?php echo $borrower['name']; ?></p>
    <p><strong>Email:</strong> <?php echo $borrower['email']; ?></p>
    <p><strong>Phone Number:</strong> <?php echo $borrower['phone']; ?></p>
    <p><strong>Address:</strong> <?php echo $borrower['address']; ?></p>
</section>

<section>
    <h2>Your Loan Details</h2>
    <p><strong>Loan Amount:</strong> <?php echo number_format($total_loan_amount); ?> pesos</p>
    <p><strong>Total Payments Made:</strong> <?php echo number_format($total_paid); ?> pesos</p>
    <p><strong>Current Balance:</strong> <?php echo number_format($current_balance); ?> pesos</p>
    <p><strong>Updated Interest Rate:</strong> <?php echo $interest_rate; ?>%</p>
    <p><strong>Updated Total Repayment Amount:</strong> <?php echo number_format($total_amount); ?> pesos</p>
    <p><strong>Loan Status:</strong> <?php echo $borrower['status']; ?></p>
</section>


<section>
    <h2>Payment Records</h2>
    <?php if (count($payments) > 0) { ?>
        <ul>
            <?php foreach ($payments as $payment) { ?>
                <li>₱<?php echo number_format($payment['amount_paid']); ?> - <?php echo date("F d, Y", strtotime($payment['date_paid'])); ?></li>
            <?php } ?>
        </ul>
    <?php } else { ?>
        <p>No payments have been made yet.</p>
    <?php } ?>
</section>
<button onclick="openNewLoanRequestModal()">Request New Loan</button>

<!-- New Loan Request Modal -->
<div id="newLoanRequestModal" class="modal" style="display: none;">
    <div class="modal-content">
        <span class="close" onclick="closeNewLoanRequestModal()">&times;</span>
        <h2>Request New Loan</h2>
        <form id="newLoanRequestForm">
            <label for="requestedAmount">Requested Amount:</label>
            <input type="number" id="requestedAmount" name="requestedAmount" required>
            <button type="button" onclick="submitNewLoanRequest()">Submit Request</button>
        </form>
    </div>
</div>


<section id="updateForm" style="display: none;">
    <h2>Update Your Password</h2>
    <form action="update_borrower_details.php" method="POST" onsubmit="return validatePasswordMatch()">
        <label for="password">New Password:</label>
        <input type="password" id="password" name="password" placeholder="Enter new password" required><br><br>

        <label for="confirmPassword">Confirm New Password:</label>
        <input type="password" id="confirmPassword" name="confirmPassword" placeholder="Confirm new password" required><br><br>

        <input type="submit" value="Update Password">
    </form>
</section>

<script>
    // When the user clicks anywhere outside of the modal, close it
    window.onclick = function(event) {
        var modal = document.getElementById('profileModal');
        if (event.target == modal) {
            modal.style.display = "none";
        }
    }
</script>
</body>
</html>
