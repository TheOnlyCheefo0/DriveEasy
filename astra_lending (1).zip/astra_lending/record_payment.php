<?php
include 'db_connect.php';

// Get input values from the form
$loan_id = $_POST['loan_id'];
$amount_paid = $_POST['amount_paid'];
$date_paid = date('Y-m-d');

// Check if the connection is working
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch the current loan amount and borrower ID
$select_amount_sql = "SELECT amount, id FROM loan_applications WHERE id = ?";
$select_stmt = $conn->prepare($select_amount_sql);
$select_stmt->bind_param("i", $loan_id);
$select_stmt->execute();
$select_stmt->bind_result($current_amount, $borrower_id);
$select_stmt->fetch();
$select_stmt->close();

// Ensure the payment doesn't exceed the current loan amount and is greater than zero
if ($amount_paid <= 0) {
    die("Error: Payment amount must be greater than zero.");
}

if ($amount_paid > $current_amount) {
    die("Error: Payment amount exceeds the current loan balance.");
}

// Insert the payment record into the payments table
$insert_sql = "INSERT INTO loan_payments (loan_id, amount_paid, date_paid) VALUES (?, ?, ?)";
$insert_stmt = $conn->prepare($insert_sql);
$insert_stmt->bind_param("ids", $loan_id, $amount_paid, $date_paid);
$insert_result = $insert_stmt->execute();

if (!$insert_result) {
    die("Error inserting payment record: " . $insert_stmt->error);
}

// Calculate the new loan amount after payment
$new_amount = $current_amount - $amount_paid;

// Determine the new interest rate
$new_interest_rate = ($new_amount >= 10000) ? 12 : 15;

// Calculate the new total amount (based on the new interest rate and remaining loan amount)
$new_total_amount = ($new_amount * ($new_interest_rate / 100));

// Update the loan application with the new amount, interest rate, and total amount
$update_sql = "UPDATE loan_applications SET amount = ?, interest_rate = ?, total_amount = ? WHERE id = ?";
$update_stmt = $conn->prepare($update_sql);
$update_stmt->bind_param("dddi", $new_amount, $new_interest_rate, $new_total_amount, $loan_id);
$update_result = $update_stmt->execute();

if (!$update_result) {
    die("Error updating loan application: " . $update_stmt->error);
}

// Check if the update was successful
if ($update_stmt->affected_rows > 0) {
    echo "Payment recorded and loan details updated successfully.";
} else {
    echo "No rows were updated. Possible causes: invalid loan ID or already zero loan amount.";
}

// Insert a notification for the borrower
$notification_message = "Your payment of ₱" . number_format($amount_paid, 2) . " has been recorded successfully.";
$sql_notification = "INSERT INTO notifications (borrower_id, message, created_at, type) VALUES (?, ?, NOW(), 'payment')";
$stmt_notification = $conn->prepare($sql_notification);
$stmt_notification->bind_param('is', $borrower_id, $notification_message);

if (!$stmt_notification->execute()) {
    die("Error inserting notification: " . $stmt_notification->error);
}

// Close statements and connection
$insert_stmt->close();
$update_stmt->close();
$stmt_notification->close();
$conn->close();
?>
