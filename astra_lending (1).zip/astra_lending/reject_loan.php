<?php
include 'db_connect.php'; // Include the database connection

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $loan_id = $_POST['loan_id'];
    $request_id = $_POST['request_id'];

    // Start transaction to ensure atomicity
    $conn->begin_transaction();

    try {
        // Update the status of the loan request to 'Rejected'
        $sql_update_request = "UPDATE loan_requests SET status = 'Rejected' WHERE request_id = ?";
        $stmt_update_request = $conn->prepare($sql_update_request);
        $stmt_update_request->bind_param('i', $request_id);
        if (!$stmt_update_request->execute()) {
            throw new Exception("Loan Request Update Failed: " . $stmt_update_request->error);
        }

        // Insert a notification for the borrower
        $notification_message = "Your loan request has been rejected.";
        $sql_notification = "INSERT INTO notifications (borrower_id, message, created_at, type) VALUES (?, ?, NOW(), 'request')";
        $stmt_notification = $conn->prepare($sql_notification);
        $stmt_notification->bind_param('is', $loan_id, $notification_message);
        if (!$stmt_notification->execute()) {
            throw new Exception("Notification Insertion Failed: " . $stmt_notification->error);
        }

        // Commit transaction
        $conn->commit();
        echo 'Loan request rejected successfully';
    } catch (Exception $e) {
        // Rollback if any query fails
        $conn->rollback();
        echo 'Error rejecting loan request: ' . $e->getMessage();
    }

    $stmt_update_request->close();
    $stmt_notification->close();
    $conn->close();
}
?>
