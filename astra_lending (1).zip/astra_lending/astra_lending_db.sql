-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 28, 2024 at 08:45 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `astra_lending_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `borrowers`
--

CREATE TABLE `borrowers` (
  `id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lenders`
--

CREATE TABLE `lenders` (
  `id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `lenders`
--

INSERT INTO `lenders` (`id`, `email`, `password`) VALUES
(7, 'lender@example.com', '$2y$10$X.IxI6.nvu53Taxg3CGkMugcVWaLYKE/9Sgiro0W8L/p.YAJtgEVq');

-- --------------------------------------------------------

--
-- Table structure for table `loan_applications`
--

CREATE TABLE `loan_applications` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `amount` decimal(10,2) DEFAULT NULL,
  `interest_rate` decimal(5,2) DEFAULT NULL,
  `total_amount` decimal(10,2) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  `confirmation_token` varchar(64) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `reset_token` varchar(255) DEFAULT NULL,
  `reset_expiry` datetime DEFAULT NULL,
  `application_date` date DEFAULT curdate(),
  `original_amount` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `loan_applications`
--

INSERT INTO `loan_applications` (`id`, `name`, `email`, `phone`, `address`, `amount`, `interest_rate`, `total_amount`, `status`, `confirmation_token`, `password`, `reset_token`, `reset_expiry`, `application_date`, `original_amount`) VALUES
(11, 'Lloyd Jacky Mendoza Mirasol', 'uzziah.lord.10@gmail.com', '09232843882', '136 Puelay Caranglaan District', 26000.00, 12.00, 2880.00, 'Approved', 'cc5db446fd63e604a1dfdc07be46acafffb2ae1da85af4d4b8f5b60bef810f0f', '$2y$10$TX15ja.WHtdILMYXE6NZw.vqAnZxI9ESGBO4QTd/XRKxQjdZyOJhu', NULL, NULL, '2024-10-16', 28000.00),
(12, 'Kiko Salinas Bro', 'likasuya.10@gmail.com', '09123456789', '150 Mangaldan', 15000.00, 12.00, 1800.00, 'Approved', '4c56678e0a67f21eaa880a172458eda1c528d8d3f7f39cd8bd19ad372eb8516a', '$2y$10$ka3hz2ixkUW..Hijl/eAEO9SsySwNSCjyyvhqAbHNgJIwHkDdvQBK', NULL, NULL, '2023-10-17', 15000.00),
(13, 'Teo Foo', 'mirasol.llydjcky@gmail.com', '0923645898', 'Bonuan Dagupan', 10000.00, 12.00, 6000.00, 'Approved', '51d71dac459f6e02a91f8696386c64bb018fe4d4fb8dc240285968acd8db4974', '$2y$10$Cqi1tB.payoi39HG.kv7t.tDKUrOxV1mhccBZc20KUJCHyt8zouLO', NULL, NULL, '2024-09-16', 10000.00),
(14, 'Josh', 'bro@gmail.com', '09123148698', 'Bonuan Dagupan', 20000.00, 12.00, 2400.00, 'Pending', '62eccf1f1e322823d998cfbfe2ba6e5e2c0e099425f6b40dbbdf04277c290509', '$2y$10$tJycL6gBfRDTQ68UhsFsuuhAaf5RF1Iu5SGm5Nc.kI9YzpaeLbLXm', NULL, NULL, '2024-10-17', 20000.00);

-- --------------------------------------------------------

--
-- Table structure for table `loan_payments`
--

CREATE TABLE `loan_payments` (
  `payment_id` int(11) NOT NULL,
  `loan_id` int(11) DEFAULT NULL,
  `amount_paid` decimal(10,2) DEFAULT NULL,
  `date_paid` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `loan_payments`
--

INSERT INTO `loan_payments` (`payment_id`, `loan_id`, `amount_paid`, `date_paid`) VALUES
(16, 11, 5000.00, '2024-10-28'),
(17, 11, 3000.00, '2024-10-28'),
(18, 11, 2000.00, '2024-10-28'),
(19, 11, 6000.00, '2024-10-28'),
(20, 11, 2000.00, '2024-10-28'),
(21, 11, 10000.00, '2024-10-28');

-- --------------------------------------------------------

--
-- Table structure for table `loan_requests`
--

CREATE TABLE `loan_requests` (
  `request_id` int(11) NOT NULL,
  `borrower_id` int(11) DEFAULT NULL,
  `requested_amount` decimal(10,2) NOT NULL,
  `request_date` datetime DEFAULT current_timestamp(),
  `status` enum('Requested','Approved','Rejected') DEFAULT 'Requested'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `loan_requests`
--

INSERT INTO `loan_requests` (`request_id`, `borrower_id`, `requested_amount`, `request_date`, `status`) VALUES
(5, 11, 5000.00, '2024-10-27 23:04:52', 'Approved'),
(6, 11, 2000.00, '2024-10-27 23:05:50', 'Approved'),
(8, 11, 2000.00, '2024-10-28 13:01:56', 'Approved'),
(9, 11, 20000.00, '2024-10-28 13:05:47', 'Approved'),
(10, 11, 2000.00, '2024-10-28 13:10:26', 'Approved'),
(12, 11, 1000.00, '2024-10-28 13:30:03', 'Approved'),
(13, 11, 1000.00, '2024-10-28 13:55:05', 'Approved'),
(14, 11, 1000.00, '2024-10-28 14:05:50', 'Rejected'),
(15, 11, 2000.00, '2024-10-28 14:12:06', 'Approved');

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `id` int(11) NOT NULL,
  `borrower_id` int(11) DEFAULT NULL,
  `message` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `type` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `notifications`
--

INSERT INTO `notifications` (`id`, `borrower_id`, `message`, `created_at`, `type`) VALUES
(12, 11, 'Your loan request has been approved', '2024-10-28 12:51:27', 'request'),
(13, 11, 'Your loan request of ₱5,000.00 has been granted.', '2024-10-28 13:05:58', 'request'),
(14, 11, 'Your loan request of ₱5,000.00 has been granted.', '2024-10-28 13:10:36', 'request'),
(15, 11, 'Your loan request of ₱1,000.00 has been granted.', '2024-10-28 13:52:02', 'request'),
(16, 11, 'Your loan request of ₱1,000.00 has been granted.', '2024-10-28 13:55:26', 'request'),
(17, 11, 'Your payment of ₱10,000.00 has been recorded successfully.', '2024-10-28 13:59:56', 'payment'),
(18, 11, 'Your loan request has been rejected.', '2024-10-28 14:09:35', 'request'),
(19, 11, 'Your loan request of ₱2,000.00 has been granted.', '2024-10-28 14:37:08', 'request');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `borrowers`
--
ALTER TABLE `borrowers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `lenders`
--
ALTER TABLE `lenders`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `loan_applications`
--
ALTER TABLE `loan_applications`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `loan_payments`
--
ALTER TABLE `loan_payments`
  ADD PRIMARY KEY (`payment_id`),
  ADD KEY `loan_id` (`loan_id`);

--
-- Indexes for table `loan_requests`
--
ALTER TABLE `loan_requests`
  ADD PRIMARY KEY (`request_id`),
  ADD KEY `borrower_id` (`borrower_id`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`id`),
  ADD KEY `notifications_ibfk_1` (`borrower_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `borrowers`
--
ALTER TABLE `borrowers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `lenders`
--
ALTER TABLE `lenders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `loan_applications`
--
ALTER TABLE `loan_applications`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `loan_payments`
--
ALTER TABLE `loan_payments`
  MODIFY `payment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `loan_requests`
--
ALTER TABLE `loan_requests`
  MODIFY `request_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `notifications`
--
ALTER TABLE `notifications`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `loan_payments`
--
ALTER TABLE `loan_payments`
  ADD CONSTRAINT `loan_payments_ibfk_1` FOREIGN KEY (`loan_id`) REFERENCES `loan_applications` (`id`);

--
-- Constraints for table `loan_requests`
--
ALTER TABLE `loan_requests`
  ADD CONSTRAINT `loan_requests_ibfk_1` FOREIGN KEY (`borrower_id`) REFERENCES `loan_applications` (`id`);

--
-- Constraints for table `notifications`
--
ALTER TABLE `notifications`
  ADD CONSTRAINT `notifications_ibfk_1` FOREIGN KEY (`borrower_id`) REFERENCES `loan_applications` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
