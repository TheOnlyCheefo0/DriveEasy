<?php
include 'db_connect.php'; // Include the database connection

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $loan_id = $_POST['loan_id'];
    $request_id = $_POST['request_id']; // Added request_id to identify the specific loan request

    // Fetch the current loan and requested amount
    $sql_fetch = "SELECT loan_applications.amount, loan_requests.requested_amount 
                  FROM loan_applications 
                  JOIN loan_requests ON loan_applications.id = loan_requests.borrower_id 
                  WHERE loan_applications.id = ? AND loan_requests.request_id = ?";
    $stmt = $conn->prepare($sql_fetch);
    $stmt->bind_param('ii', $loan_id, $request_id); // Bind both loan_id and request_id
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $current_amount = $row['amount'];
        $requested_amount = $row['requested_amount'];

        // Update the current loan amount by adding the requested amount
        $new_amount = $current_amount + $requested_amount;

        // Start transaction to ensure atomicity
        $conn->begin_transaction();

        try {
            // Update loan application with the new amount
            $sql_update = "UPDATE loan_applications SET amount = ? WHERE id = ?";
            $stmt_update = $conn->prepare($sql_update);
            $stmt_update->bind_param('di', $new_amount, $loan_id);
            if (!$stmt_update->execute()) {
                throw new Exception("Loan Application Update Failed: " . $stmt_update->error);
            }

            // Update the status of the specific loan request to 'Approved'
            $sql_update_request = "UPDATE loan_requests SET status = 'Approved' WHERE request_id = ?";
            $stmt_update_request = $conn->prepare($sql_update_request);
            $stmt_update_request->bind_param('i', $request_id);
            if (!$stmt_update_request->execute()) {
                throw new Exception("Loan Request Update Failed: " . $stmt_update_request->error);
            }

            // Insert a notification for the borrower
            $notification_message = "Your loan request of ₱" . number_format($requested_amount, 2) . " has been granted.";
            $sql_notification = "INSERT INTO notifications (borrower_id, message, created_at, type) VALUES (?, ?, NOW(), 'request')";
            $stmt_notification = $conn->prepare($sql_notification);
            $stmt_notification->bind_param('is', $loan_id, $notification_message);
            if (!$stmt_notification->execute()) {
                throw new Exception("Notification Insertion Failed: " . $stmt_notification->error);
            }

            // Commit transaction
            $conn->commit();
            echo 'Loan granted successfully';
        } catch (Exception $e) {
            // Rollback if any query fails
            $conn->rollback();
            echo 'Error granting loan: ' . $e->getMessage();
        }
    } else {
        echo 'Loan not found';
    }

    $stmt->close();
    $conn->close();
}
?>
